<p align="center"><!-- Row 1: Core Status Badges -->
  <img src="https://img.shields.io/github/actions/workflow/status/hamedcode/port-based-v2ray-configs/main.yml?style=for-the-badge&logo=githubactions&logoColor=white" alt="Actions Status"><a href="https://hamedcode.github.io/port-based-v2ray-configs/" target="_blank">
    <img src="https://img.shields.io/badge/github-pages-121013?style=for-the-badge&logo=github&logoColor=white" alt="GitHub Pages"></a>
  <img src="https://img.shields.io/github/last-commit/hamedcode/port-based-v2ray-configs?style=for-the-badge&logo=git&logoColor=white" alt="Last Commit">
<img alt="GitHub License" src="https://img.shields.io/github/license/Hamedcode/port-based-v2ray-configs?style=for-the-badge">
<br><!-- Row 2: Stats & Social Badges -->
  <img src="https://komarev.com/ghpvc/?username=hamedcode&repo=port-based-v2ray-configs&color=blue&style=for-the-badge" alt="Visitors">
  <img alt="GitHub Release" src="https://img.shields.io/github/v/release/hamedcode/port-based-v2ray-configs?style=for-the-badge">
  <img src="https://img.shields.io/badge/Python-14354C?style=for-the-badge&logo=python&logoColor=white" alt="python">
  
<p align="center"><!-- Row 3: Core Status Badges -->
  <img src="https://img.shields.io/github/stars/hamedcode/port-based-v2ray-configs?style=social" alt="GitHub Stars">
  <img src="https://img.shields.io/github/forks/hamedcode/port-based-v2ray-configs?style=social" alt="GitHub Forks"></p>


---

# 💠 Port-Based V2Ray Configs

This repository contains a collection of V2Ray configurations, aggregated from various public sources. The configs are automatically categorized by protocol and port using a Python script.

> [!NOTE]
> If you find this repository helpful, please consider giving it a star ⭐. Your support is greatly appreciated!
---

## 📊 Config Stats

<!-- START-STATS -->
_Last update: 2026-08-20 19:49:33 GMT+3:30_

| Protocol | 80 | 443 | 2053 | 8880 | 2087 | 2096 | 8443 | Total |
|---|---|---|---|---|---|---|---|---|
| VLESS | 476 | 5935 | 420 | 495 | 191 | 158 | 753 | 11305 |
| VMESS | 341 | 965 | 37 | 38 | 8 | 7 | 59 | 2260 |
| TROJAN | 17 | 3937 | 36 | 0 | 5 | 3 | 40 | 4596 |
| SS | 23 | 484 | 0 | 0 | 0 | 0 | 4 | 2990 |
| OTHER | 0 | 0 | 0 | 0 | 0 | 0 | 0 | 41 |
<!-- END-STATS -->

---

## 🔗 Subscription Links

<!-- START-LINKS -->
### By Port
| Port | Count | Subscription Link |
|---|---|---|
| 80 | 857 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_80.txt) |
| 443 | 11321 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_443.txt) |
| 2053 | 493 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_2053.txt) |
| 8880 | 533 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_8880.txt) |
| 2087 | 204 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_2087.txt) |
| 2096 | 168 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_2096.txt) |
| 8443 | 856 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/port_8443.txt) |

### By Protocol
| Protocol | Count | Subscription Link |
|---|---|---|
| VLESS | 11305 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/vless.txt) |
| VMESS | 2260 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/vmess.txt) |
| TROJAN | 4596 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/trojan.txt) |
| SS | 2990 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/ss.txt) |
| OTHER | 41 | [Sub Link](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/other.txt) |

### By Protocol & Port (Common Ports)

<table width="100%" style="border: none; border-collapse: collapse;">
  <tr style="background-color: transparent;">
    <td width="50%" valign="top" style="border: none; padding-right: 10px;">
      <table><thead><tr><th>Protocol</th><th>Port</th><th>Count</th><th>Link</th></tr></thead><tbody><tr><td>VLESS</td><td>80</td><td>476</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/80.txt">Sub</a></td></tr><tr><td>VLESS</td><td>443</td><td>5935</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/443.txt">Sub</a></td></tr><tr><td>VLESS</td><td>2053</td><td>420</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/2053.txt">Sub</a></td></tr><tr><td>VLESS</td><td>8880</td><td>495</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/8880.txt">Sub</a></td></tr><tr><td>VLESS</td><td>2087</td><td>191</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/2087.txt">Sub</a></td></tr><tr><td>VLESS</td><td>2096</td><td>158</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/2096.txt">Sub</a></td></tr><tr><td>VLESS</td><td>8443</td><td>753</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vless/8443.txt">Sub</a></td></tr><tr style="border-top: 2px solid #d0d7de;"><td>VMESS</td><td>80</td><td>341</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/80.txt">Sub</a></td></tr><tr><td>VMESS</td><td>443</td><td>965</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/443.txt">Sub</a></td></tr><tr><td>VMESS</td><td>2053</td><td>37</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/2053.txt">Sub</a></td></tr><tr><td>VMESS</td><td>8880</td><td>38</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/8880.txt">Sub</a></td></tr><tr><td>VMESS</td><td>2087</td><td>8</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/2087.txt">Sub</a></td></tr></tbody></table>
    </td>
    <td width="50%" valign="top" style="border: none; padding-left: 10px;">
      <table><thead><tr><th>Protocol</th><th>Port</th><th>Count</th><th>Link</th></tr></thead><tbody><tr><td>VMESS</td><td>2096</td><td>7</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/2096.txt">Sub</a></td></tr><tr><td>VMESS</td><td>8443</td><td>59</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/vmess/8443.txt">Sub</a></td></tr><tr style="border-top: 2px solid #d0d7de;"><td>TROJAN</td><td>80</td><td>17</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/80.txt">Sub</a></td></tr><tr><td>TROJAN</td><td>443</td><td>3937</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/443.txt">Sub</a></td></tr><tr><td>TROJAN</td><td>2053</td><td>36</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/2053.txt">Sub</a></td></tr><tr><td>TROJAN</td><td>2087</td><td>5</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/2087.txt">Sub</a></td></tr><tr><td>TROJAN</td><td>2096</td><td>3</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/2096.txt">Sub</a></td></tr><tr><td>TROJAN</td><td>8443</td><td>40</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/trojan/8443.txt">Sub</a></td></tr><tr style="border-top: 2px solid #d0d7de;"><td>SS</td><td>80</td><td>23</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/ss/80.txt">Sub</a></td></tr><tr><td>SS</td><td>443</td><td>484</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/ss/443.txt">Sub</a></td></tr><tr><td>SS</td><td>8443</td><td>4</td><td><a href="https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/detailed/ss/8443.txt">Sub</a></td></tr></tbody></table>
    </td>
  </tr>
</table>

<!-- END-LINKS -->

> [!NOTE]
> For a complete list of all protocols and ports, browse the [`sub`](https://github.com/hamedcode/port-based-v2ray-configs/tree/main/sub) and [`detailed`](https://github.com/hamedcode/port-based-v2ray-configs/tree/main/detailed) directories.

---

## 📚 Sources & Summary

<!-- START-SOURCES -->

<table width="100%" style="border: none; border-collapse: collapse;">
  <tr style="background-color: transparent;">
    <td width="50%" valign="top" style="border: none; padding-right: 10px;">
      <h4>Sources</h4>
      <table><thead><tr><th>Source</th><th>Fetched Lines</th></tr></thead><tbody><tr><td>ConfigForge-V2Ray</td><td>1670</td></tr><tr><td>Epodonios</td><td>7102</td></tr><tr><td>Hamedp-71</td><td>2390</td></tr><tr><td>Rayan-Config</td><td>47</td></tr><tr><td>barry-far</td><td>7102</td></tr><tr><td>kobabi</td><td>350</td></tr><tr><td>mahdibland</td><td>4546</td></tr><tr><td>yebekhe</td><td>306</td></tr></tbody></table>
    </td>
    <td width="50%" valign="top" style="border: none; padding-left: 10px;">
      <h4>Summary</h4>
      <table><thead><tr><th>Metric</th><th>Value</th></tr></thead><tbody><tr><td>Total Fetched</td><td>23513</td></tr><tr><td>Unique Configs</td><td>21192</td></tr><tr><td>Duplicates Removed</td><td>2321</td></tr></tbody></table>
    </td>
  </tr>
</table>

<!-- END-SOURCES -->

---

## 🟢 Live Configs (Tested)

Every run, configs go through a liveness pipeline before `top100`/`clash.yaml` are built:

1. **TCP check** (3 rounds, directly from the runner) — drops configs whose port isn't even open.
2. **Real proxy test** (via a WireGuard tunnel, so the target servers see a VPN exit IP instead of GitHub's — multiple WireGuard configs are supported with automatic failover) — actually connects through each config with [xray-knife](https://github.com/lilendian0x00/xray-knife) and confirms it can reach the internet.
3. The fastest configs that passed both stages become `top100.txt` (up to 100), and a ready-to-import `clash.yaml` is built from the same set.

If the WireGuard tunnel is unavailable for a run, the pipeline falls back to TCP-only ranking automatically (noted in the table below) instead of failing the whole workflow.

<!-- START-LIVENESS -->
_Liveness data appears here after the next workflow run._
<!-- END-LIVENESS -->

- [top100.txt](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/top100.txt) — top 100 configs, sorted by speed
- [clash.yaml](https://raw.githubusercontent.com/hamedcode/port-based-v2ray-configs/main/sub/clash.yaml) — ready-to-import Clash/Mihomo config (top 100 only)

> [!NOTE]
> Requires a `WG_CONFIGS` repository secret (one or more WireGuard configs). See [`docs/WIREGUARD_SETUP.md`](docs/WIREGUARD_SETUP.md) for the format and setup instructions.
